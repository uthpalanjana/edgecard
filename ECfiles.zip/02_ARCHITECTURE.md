# ContextPack Architecture

## System Overview

ContextPack has two runtime phases with distinct responsibilities:

**Authoring phase** — the developer/operator defines a CardDefinition
once. This is a declarative description of what a card should contain:
identity fields, knowledge, rules, data sources, and token budget. This
runs once at deployment time.

**Write cycle** — the CardWriter runs on a schedule. On each cycle it
polls all registered data sources, computes derived state, applies the
RuleEngine to generate/update the instructions block, enforces the token
budget, and writes the card to disk. This runs continuously at a
configurable interval.

The model consumes the card at inference time by reading the file. It
never calls back into ContextPack. The boundary between ContextPack and
the model is a file on disk.

---

## Component Map

```
┌─────────────────────────────────────────────────────┐
│                   AUTHORING PHASE                    │
│                                                      │
│  Developer writes:                                   │
│  CardDefinition                                      │
│    ├── identity fields                               │
│    ├── KnowledgeBlock (static)                       │
│    ├── Rule objects  ──────────────► RuleEngine      │
│    ├── DataSource registrations                      │
│    ├── token_budget + allocations                    │
│    └── contacts + escalation config                  │
└─────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────┐
│                    WRITE CYCLE                       │
│                                                      │
│  CardWriter (runs every N seconds)                   │
│    │                                                 │
│    ├── Poll all DataSources                          │
│    │     ├── MQTTAdapter                             │
│    │     ├── ModbusAdapter                           │
│    │     ├── RESTAdapter                             │
│    │     ├── FileAdapter                             │
│    │     └── MockAdapter                             │
│    │                                                 │
│    ├── Compute derived state                         │
│    │     ├── trends from ring buffer                 │
│    │     ├── rate_of_change calculations             │
│    │     ├── threshold breach detection              │
│    │     └── history-derived counts                  │
│    │                                                 │
│    ├── RuleEngine.evaluate(state)                    │
│    │     └── generates instructions block            │
│    │                                                 │
│    ├── BudgetEnforcer.enforce(card)                  │
│    │     ├── measure tokens per block                │
│    │     ├── summarise blocks over budget            │
│    │     └── reject if total exceeds ceiling         │
│    │                                                 │
│    ├── Validator.validate(card)                      │
│    │     └── raises CardValidationError if invalid   │
│    │                                                 │
│    ├── Signer.sign(card)  [if signing enabled]       │
│    ├── Encryptor.encrypt(card)  [if encryption on]   │
│    │                                                 │
│    └── write card to disk as YAML                    │
│          path: {output_dir}/{card_id}.card.yaml      │
└─────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────┐
│                  CARD FILE ON DISK                   │
│                                                      │
│  {card_id}.card.yaml  (storage format)               │
│  {card_id}.card.yaml.sig  (if signed)                │
└─────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────┐
│               MODEL INJECTION (by consumer)          │
│                                                      │
│  CardReader.load(card_id)                            │
│    ├── reads YAML from disk                          │
│    ├── verifies signature  [if signed]               │
│    ├── decrypts  [if encrypted]                      │
│    ├── loads dependency cards  [from dependencies[]] │
│    └── encodes for model:                            │
│          ├── structured blocks → TOON (default)      │
│          └── instructions block → plain text         │
│                                                      │
│  Returns: model-ready string ready for system prompt │
└─────────────────────────────────────────────────────┘
                         │
                         ▼
              Local LLM (Ollama, llama.cpp, etc.)
              NOT ContextPack's responsibility
```

---

## Core Classes

### CardDefinition

The user-facing authoring object. Immutable after construction.

```python
class CardDefinition:
    card_id: str
    card_type: CardType
    subject: str
    location: str
    token_budget: int = 800
    token_allocation: dict = DEFAULT_ALLOCATION
    write_interval_seconds: int = 120
    staleness_threshold_seconds: int = 300
    output_dir: Path = Path("./cards")
    signing_enabled: bool = False
    encryption_enabled: bool = False
    contacts: list[Contact] = []

    def add_knowledge_fact(key, value, tags) -> None
    def add_threshold(field, operator, value, severity, label) -> None
    def add_rule(rule: Rule) -> None
    def add_data_source(source: DataSource) -> None
    def add_dependency(card_id: str) -> None
```

### Rule

The domain logic unit. Users write one Rule per condition they want the
model to reason about.

```python
class Rule:
    rule_id: str
    name: str
    condition: str          # plain language or structured condition
                            # e.g. "temperature_c > 8.0"
                            # e.g. "compressor_status == OFF and temperature_c > 7.5"
    directive: str          # plain language instruction to the model
    priority: Priority      # info | warning | critical
    applies_to_card_types: list[CardType]
    enabled: bool = True
```

### RuleEngine

Translates Rule objects into instructions block directives.

```python
class RuleEngine:
    def evaluate(rules: list[Rule], state: StateBlock) -> InstructionsBlock
    def translate_condition(condition: str) -> str
    def translate_directive(directive: str, priority: Priority) -> str
    def generate_mandatory_directives(definition: CardDefinition) -> list[str]
```

The translation from user condition to model directive is the core
intellectual function of ContextPack. The RuleEngine must:

1. Parse the condition string into a structured form
2. Map field names to their location in the card schema
   (`temperature_c` → `state.readings.temperature_c.value`)
3. Render the directive with appropriate emphasis based on priority
4. Add conditional guards (only emit directive if field exists in state)

### DataSource (abstract base)

```python
class DataSource(ABC):
    name: str
    poll_interval_seconds: int

    @abstractmethod
    def poll() -> dict[str, Reading]

    @abstractmethod
    def test_connection() -> ConnectionResult
```

Every adapter implements this interface. `poll()` returns a dict of
field names to Reading objects. The CardWriter calls `poll()` on all
registered sources each write cycle and merges the results.

### CardWriter

The runtime scheduler and assembly engine.

```python
class CardWriter:
    definition: CardDefinition
    rule_engine: RuleEngine
    budget_enforcer: BudgetEnforcer
    validator: Validator
    signer: Optional[Signer]
    encryptor: Optional[Encryptor]
    history_store: HistoryStore

    def start() -> None           # begins write loop in background thread
    def stop() -> None
    def write_now() -> Card       # force a single write cycle (for CLI/testing)
    def get_last_card() -> Card   # returns most recently written card
```

### CardReader

Used by the model consumer (or the CLI) to load a card and encode it.

```python
class CardReader:
    def load(card_path: Path) -> Card
    def load_with_dependencies(card_path: Path) -> list[Card]
    def encode(card: Card, encoding: Encoding) -> str
    def encode_for_model(cards: list[Card], encoding: Encoding) -> str
```

`encode_for_model` handles the multi-card case: when a device card has
dependencies, all cards are encoded and concatenated in dependency order
(dependencies first, primary card last).

---

## Adapter Architecture

All adapters follow the same pattern:

```python
class MQTTAdapter(DataSource):
    broker_host: str
    broker_port: int
    topics: list[MQTTTopicMapping]
    # MQTTTopicMapping maps a topic string to a field name and unit

    def poll() -> dict[str, Reading]
    def test_connection() -> ConnectionResult
```

Adapters do not interpret readings. They return raw values mapped to
field names. Interpretation (what a reading means, whether it's a
breach) is the RuleEngine's job.

---

## Encoder Architecture

Each encoder takes a Card object and returns a string.

```python
class ToonEncoder(Encoder):
    def encode(card: Card) -> str
    # Encodes structured blocks (state, knowledge, history) as TOON
    # Encodes instructions block as plain text
    # Identity block as TOON header

class YAMLEncoder(Encoder):
    def encode(card: Card) -> str
    # Full YAML — used for disk storage, not model injection

class JSONEncoder(Encoder):
    def encode(card: Card) -> str

class PlainTextEncoder(Encoder):
    def encode(card: Card) -> str
    # Human-readable narrative format — useful for debugging
```

The default injection encoding is TOON. The storage encoding is always
YAML. These are separate concerns and must not be conflated.

---

## History Store

The HistoryStore persists events across write cycles. Without it, the
history block would be empty on every restart.

```python
class HistoryStore:
    storage_path: Path       # {output_dir}/{card_id}.history.json

    def append_event(event: HistoryEvent) -> None
    def get_recent(n: int) -> list[HistoryEvent]
    def get_summary(days: int) -> str
    def get_fault_count(event_type: str, days: int) -> int
    def trim(max_events: int) -> None
```

Events are appended by the CardWriter when threshold breaches are
detected. The CardWriter compares the current state against thresholds
on every write cycle and creates HistoryEvents when transitions occur
(normal → breach, breach → resolved).

---

## Dependency Loading

When `CardReader.load_with_dependencies()` is called, it:

1. Reads the primary card's `identity.dependencies` list
2. Loads each dependency card from the same output directory
3. Recursively loads their dependencies (max depth: 5)
4. Returns the full list in topological order (deepest dependency first)

The model injection string is assembled as:

```
[dependency card 1 encoded]
---
[dependency card 2 encoded]
---
[primary card encoded]
```

The separator `---` is a clear section boundary the model can use to
distinguish card scope.

---

## Crypto Architecture

### Signing

Uses Ed25519 (fast, small signatures, suitable for edge hardware).

```python
class Signer:
    private_key: Ed25519PrivateKey

    def sign(card_yaml: str) -> str        # returns base64 signature
    def verify(card_yaml: str, sig: str, public_key: Ed25519PublicKey) -> bool
```

The signature covers the card body (everything except the provenance
block). This allows provenance to be updated without invalidating the
signature.

### Encryption

Uses AES-256-GCM (authenticated encryption — integrity and
confidentiality in one operation).

```python
class Encryptor:
    key: bytes              # 32-byte AES key
    key_id: str             # human-readable reference stored in provenance

    def encrypt(card_yaml: str) -> EncryptedCard
    def decrypt(encrypted: EncryptedCard) -> str
```

Encryption applies to the full card body. The card_id and schema_version
remain in plaintext in the file header so the reader knows what it has
before decrypting.

---

## CLI Architecture

The CLI is the primary testing and validation interface.

```
contextpack [command] [options]

Commands:
  generate    Run a single write cycle and print the result
  validate    Validate a card file against the schema
  encode      Re-encode an existing card in a specified format
  watch       Run the CardWriter continuously (for development)
  test-source Test connectivity for all adapters in a definition file
  inspect     Pretty-print a card with token counts per block
```

The CLI reads a CardDefinition from a Python file or a YAML definition
file (for non-Python users). This is the path that enables operators
without Python knowledge to use ContextPack.

### YAML CardDefinition format (for CLI non-Python users)

```yaml
# my_device.definition.yaml
card_id: "my-device-001"
card_type: "device"
subject: "My Sensor Device"
location: "Building A, Floor 2"
token_budget: 800
write_interval_seconds: 120

knowledge:
  thresholds:
    - field: temperature_c
      operator: gt
      value: 35.0
      severity: critical
      label: "Temperature critical"
  facts:
    - key: device_purpose
      value: "Monitors ambient temperature in server room"

rules:
  - rule_id: temp_critical
    name: "Critical Temperature"
    condition: "temperature_c > 35.0"
    directive: "Alert immediately. Recommend activating backup cooling."
    priority: critical

sources:
  - type: mqtt
    name: temperature_sensor
    broker_host: "192.168.1.100"
    broker_port: 1883
    topics:
      - topic: "sensors/temp"
        field: temperature_c
        unit: celsius
```

---

## Multi-SDK Consistency

All three SDKs (Python, TypeScript, Rust) must produce identical output
for the same input. The canonical behaviour is defined by:

1. This architecture document
2. The schema in `docs/01_SCHEMA.md`
3. The integration tests in each SDK's test suite

An integration test suite in `/tests/cross_sdk/` must verify that a
card generated by the Python SDK can be read and validated by the
TypeScript and Rust SDKs. This test must run in CI.

---

## Error Handling Philosophy

ContextPack should fail loudly at authoring time and fail gracefully at
write time.

**Authoring time (loud):**
- Missing mandatory fields in CardDefinition → raise immediately
- Invalid Rule condition syntax → raise immediately
- Incompatible adapter configuration → raise immediately

**Write cycle (graceful):**
- Adapter poll failure → write card with stale readings and quality: stale
- Token budget exceeded → summarise and write, log warning
- Individual field missing from poll → write card without that field,
  log warning
- Signing/encryption failure → do NOT write card, raise and log error
  (a card that should be signed but isn't is worse than no card)

The CardWriter must never silently produce a degraded card. Every
degradation must be logged with enough context to diagnose.
