# ContextPack Implementation Plan

## Build Order

Follow this order exactly. Each phase depends on the previous.
Do not begin a phase until all tasks in the prior phase pass their tests.

---

## Phase 0 — Project Scaffolding

### Python

- [ ] Initialise `python/` with `pyproject.toml`
- Dependencies: `pyyaml`, `pydantic`, `paho-mqtt`, `pymodbus`,
  `httpx`, `cryptography`, `click`, `tiktoken`
- [ ] Create package structure as defined in `CLAUDE.md`
- [ ] Set up `pytest` with `tests/` directory
- [ ] Create `contextpack/__init__.py` that exports the public API:
  `CardDefinition, Rule, DataSource, CardWriter, CardReader, Encoding`

### TypeScript

- [ ] Initialise `typescript/` with `package.json`
- Dependencies: `js-yaml`, `zod`, `mqtt`, `modbus-serial`, `axios`,
  `@noble/ed25519`, `commander`
- [ ] Create `src/index.ts` with public exports
- [ ] Set up `jest` for testing

### Rust

- [ ] Initialise `rust/` with `Cargo.toml`
- Dependencies: `serde`, `serde_yaml`, `serde_json`, `tokio`,
  `rumqttc`, `tokio-modbus`, `reqwest`, `ed25519-dalek`, `aes-gcm`,
  `clap`
- [ ] Create `src/lib.rs` with public module exports

---

## Phase 1 — Schema and Core Types

Build the data model before any business logic.

### Python (implement first, others mirror)

- [ ] `card.py` — implement all dataclasses/Pydantic models:
  - `CardType` enum
  - `Priority` enum
  - `Quality` enum
  - `Trend` enum
  - `Operator` enum
  - `EventType` enum
  - `Reading` dataclass
  - `StateBlock` dataclass
  - `KnowledgeBlock` dataclass
  - `HistoryEvent` dataclass
  - `HistoryBlock` dataclass
  - `InstructionsBlock` dataclass
  - `ProvenanceBlock` dataclass
  - `Card` dataclass (top-level)
  - `CardDefinition` class with all methods from architecture doc

- [ ] `schema/contextpack-v1.schema.json` — generate from Pydantic models

- [ ] Tests: `tests/test_schema.py`
  - Test all enum values
  - Test Card construction with all blocks
  - Test CardDefinition builder methods
  - Test schema validation against the JSON Schema
  - Test forward compatibility (schema v1.1 card readable by v1.0 validator)

### TypeScript
- [ ] Mirror all types in `src/card.ts` using Zod schemas
- [ ] Tests mirror Python test coverage

### Rust
- [ ] Mirror all types in `src/card.rs` using serde
- [ ] Tests mirror Python test coverage

---

## Phase 2 — Rule Engine

The most important component. Build it carefully.

### Python

- [ ] `rules.py` — implement:

  **Rule class**
  - All fields from architecture doc
  - `validate()` method that checks condition string is parseable

  **ConditionParser**
  - Parses condition strings into structured form
  - Supported operators: `>`, `<`, `>=`, `<=`, `==`, `!=`
  - Supported connectors: `and`, `or`
  - Field names map to `state.readings.<field>.value` automatically
  - Special fields: `derived_state.<field>` for derived values
  - Must raise `InvalidConditionError` for unparseable conditions

  **DirectiveRenderer**
  - Takes a Rule and renders it as a model directive string
  - Priority mapping:
    - `critical` → adds "CRITICAL PRIORITY" and "must not be omitted"
    - `warning` → adds emphasis but no mandatory language
    - `info` → plain directive
  - Field references in rendered text use full schema paths

  **MandatoryDirectiveGenerator**
  - Generates the 4 mandatory directives from CardDefinition config
  - Role directive uses `identity.subject`
  - Staleness directive uses `staleness_threshold_seconds`
  - Output terminus uses `contacts` list

  **RuleEngine**
  - `evaluate(rules, state, definition)` → `InstructionsBlock`
  - Filters rules by `applies_to_card_types`
  - Filters rules by `enabled`
  - For each active rule: renders directive, appends to block
  - Generates mandatory directives
  - Assembles complete InstructionsBlock

- [ ] Tests: `tests/test_rules.py`
  - Test condition parsing: simple, compound, edge cases
  - Test directive rendering at each priority level
  - Test mandatory directive generation
  - Test full RuleEngine.evaluate() with mock state
  - Test that invalid conditions raise correctly
  - Test that rules for wrong card_type are filtered out
  - **Critical test**: verify that the same Rule + State always produces
    the same directive (determinism)

### TypeScript and Rust
- [ ] Mirror implementation and tests

---

## Phase 3 — Adapters

Build adapters in this order: Mock first (needed for all other tests),
then File, then REST, then MQTT, then Modbus.

### Mock Adapter (all three SDKs)

- [ ] `adapters/mock.py`
  - Constructor takes a dict of `{field_name: value}` or a callable
    that returns a dict (for time-varying mock data)
  - `poll()` returns readings with `quality: simulated`
  - `test_connection()` always returns success
  - Must support seeded random variation for testing trend detection

- [ ] Tests: verify poll() returns correct Reading objects

### File / CSV Adapter (all three SDKs)

- [ ] `adapters/file.py`
  - Reads a CSV or JSON file on each poll
  - CSV format: `timestamp,field_name,value,unit`
  - JSON format: `{field_name: {value: x, unit: y, timestamp: z}}`
  - `test_connection()` verifies file exists and is readable
  - Handles file-not-found gracefully (returns stale readings)

- [ ] Tests: test with fixture CSV and JSON files

### REST Adapter (all three SDKs)

- [ ] `adapters/rest.py`
  - Constructor takes base_url, endpoint mappings, optional auth config
  - EndpointMapping: `{endpoint: str, field: str, json_path: str, unit: str}`
  - `json_path` is a dot-notation path into the response JSON
  - `poll()` fires all configured endpoints, extracts values
  - Timeout: configurable, default 5 seconds
  - On timeout or HTTP error: returns stale readings, logs warning
  - `test_connection()` fires a HEAD request to base_url

- [ ] Tests: use `httpx` mock responses

### MQTT Adapter (all three SDKs)

- [ ] `adapters/mqtt.py`
  - Constructor: `broker_host`, `broker_port`, `topics: list[MQTTTopicMapping]`
  - `MQTTTopicMapping`: `topic: str, field: str, unit: str,
    json_path: Optional[str]`
  - Maintains a persistent connection with auto-reconnect
  - `poll()` returns the most recent value received per topic
  - If no message received since last poll: returns stale reading
  - Supports plain value payloads and JSON payloads (via json_path)
  - `test_connection()` connects, subscribes to first topic, waits 3s
    for any message, disconnects

- [ ] Tests: use MQTT mock broker (e.g. `asyncio_mqtt` with mock)

### Modbus Adapter (all three SDKs)

- [ ] `adapters/modbus.py`
  - Constructor: `host`, `port`, `unit_id`, `registers: list[RegisterMapping]`
  - `RegisterMapping`: `address: int, field: str, register_type: enum,
    data_type: enum, scale_factor: float, unit: str`
  - `register_type`: holding | input | coil | discrete_input
  - `data_type`: uint16 | int16 | uint32 | int32 | float32 | boolean
  - `poll()` groups reads by register_type, fires minimal read operations
  - `test_connection()` reads a single holding register at address 0

- [ ] Tests: use pymodbus simulator

---

## Phase 4 — Card Writer

- [ ] `writer.py`

  **DerivedStateComputer**
  - `compute_trend(field, ring_buffer)` → Trend enum
    - Uses last 5 readings, configurable window
    - Rising: monotonically increasing over window
    - Falling: monotonically decreasing
    - Stable: variance below threshold
    - Unknown: insufficient data
  - `compute_rate_of_change(field, ring_buffer)` → float (per hour)
  - `compute_breach_state(readings, thresholds)` → dict of breach flags
  - `update_derived_from_history(state, history_store)` → adds fault counts

  **BudgetEnforcer**
  - `measure_tokens(block, encoder)` → int
    Uses tiktoken cl100k_base as default tokeniser
  - `enforce(card, budget, allocation)` → Card
    Summarises over-budget blocks, never truncates
  - `summarise_history(history_block, target_tokens)` → HistoryBlock
  - `summarise_knowledge(knowledge_block, target_tokens)` → KnowledgeBlock

  **CardWriter**
  - Implements full write cycle as described in architecture doc
  - `start()` launches background thread/async task
  - `stop()` gracefully stops, waits for current cycle to complete
  - `write_now()` synchronous single cycle, returns Card
  - Ring buffer per field: stores last 10 readings for trend computation
  - Threshold transition detection for history event creation
  - Configurable write interval (default 120s)

- [ ] Tests: `tests/test_writer.py`
  - Test full write cycle with MockAdapter
  - Test derived state computation
  - Test budget enforcement (over-budget card gets summarised)
  - Test threshold transition → history event creation
  - Test start/stop lifecycle
  - Test write_now() returns valid card

---

## Phase 5 — Encoders

- [ ] `encoders/yaml_encoder.py` — roundtrip serialisation (storage format)
- [ ] `encoders/json_encoder.py` — standard JSON
- [ ] `encoders/toon_encoder.py` — TOON encoding
- [ ] `encoders/text_encoder.py` — human-readable narrative

### TOON Encoder Detail

The TOON encoder is the most important encoder. It must:

1. Encode the state.readings block as a uniform TOON array:
   ```
   readings[N]{field,value,unit,quality,trend,rate_of_change}:
   temperature_c,8.7,celsius,measured,rising,1.2
   compressor_status,OFF,,measured,,,
   ```

2. Encode the history.events block as a TOON array:
   ```
   events[N]{event_id,event_type,timestamp,severity,resolved,description}:
   evt-002,fault,2026-02-14T11:20:00Z,critical,true,Temperature breach 9.1C
   ```

3. Encode the knowledge.domain_facts as a TOON array:
   ```
   facts[N]{key,value}:
   mrna_stability,COVID-19 mRNA vaccines require 2-8C. Zero tolerance above 8C.
   ```

4. Encode the identity and derived_state blocks as YAML-like key-value
   (not arrays — they are non-uniform objects)

5. Encode the instructions block as plain text, NOT TOON:
   ```
   ## INSTRUCTIONS
   You are a cold chain incident assistant...
   [directives as numbered list]
   ```

- [ ] Tests: `tests/test_encoders.py`
  - Test TOON encoding of each block type
  - Test TOON decoder (round-trip)
  - Test token counts are lower in TOON than JSON for array blocks
  - Test that instructions block is always plain text regardless of encoder
  - Test PlainTextEncoder produces human-readable output

---

## Phase 6 — Card Reader

- [ ] `reader.py`
  - `load(path)` — reads YAML, verifies schema version compatibility
  - `load_with_dependencies(path, card_dir)` — recursive dependency loading
    with cycle detection and max depth 5
  - `verify_signature(card, public_key)` → bool
  - `decrypt(card, key)` → Card
  - `encode_for_model(cards, encoding)` → str
    Concatenates multiple cards with `---` separator in dependency order

- [ ] Tests: `tests/test_reader.py`
  - Test load with valid card
  - Test load with invalid schema version
  - Test dependency loading with 2-level dependency chain
  - Test cycle detection in dependencies
  - Test signature verification (valid and tampered)
  - Test multi-card encoding order

---

## Phase 7 — Crypto

- [ ] `crypto.py`
  - `Signer` using Ed25519 (cryptography library)
  - `Encryptor` using AES-256-GCM
  - `KeyManager` — helpers for key generation and loading from file/env var
  - Keys must be loadable from:
    - File path (PEM for signing, raw bytes for AES)
    - Environment variable
    - Explicit bytes

- [ ] Tests: `tests/test_crypto.py`
  - Test sign and verify round-trip
  - Test tampered card fails verification
  - Test encrypt/decrypt round-trip
  - Test key loading from file and env var

---

## Phase 8 — History Store

- [ ] `history.py`
  - `HistoryStore` backed by a local JSON file
  - Thread-safe (write lock around append operations)
  - `append_event(event)` — appends and immediately flushes to disk
  - `get_recent(n)` — returns n most recent events sorted by timestamp
  - `get_summary(days)` — returns a plain text summary string
  - `get_fault_count(event_type, days)` — count of events in window
  - `trim(max_events)` — removes oldest events, keeps max_events

- [ ] Tests: `tests/test_history.py`
  - Test append and retrieve
  - Test summary generation
  - Test fault count window
  - Test trim
  - Test thread safety (concurrent appends)
  - Test persistence across HistoryStore restart

---

## Phase 9 — CLI

- [ ] `cli/main.py` using Click

```
contextpack generate --definition my_device.py --output ./cards
contextpack generate --definition my_device.definition.yaml --output ./cards
contextpack validate --card ./cards/my-device.card.yaml
contextpack encode --card ./cards/my-device.card.yaml --format toon
contextpack encode --card ./cards/my-device.card.yaml --format json
contextpack watch --definition my_device.py --output ./cards --interval 30
contextpack test-source --definition my_device.py
contextpack inspect --card ./cards/my-device.card.yaml
```

`inspect` output must show:
- Card summary (id, type, subject, generated_at, valid_until)
- Token count per block
- Total token count vs budget
- List of active rules and their generated directives
- Data quality summary (how many readings are measured vs stale)

- [ ] Tests: `tests/test_cli.py` using Click test runner

---

## Phase 10 — Examples

Three complete working examples. Each must:
- Be self-contained (no external dependencies beyond ContextPack)
- Use MockAdapter so they work without real hardware
- Include a `demo.py` / `demo.ts` that generates a card and prints TOON output
- Include a `README.md` explaining what the example demonstrates

### examples/cold_chain/
- Pharmaceutical refrigeration unit
- Two products with different stability profiles
- Breach detection with recoverable/non-recoverable classification
- Two-event history showing recurring fault pattern

### examples/smart_home/
- Apartment device support card
- Thread mesh network topology in knowledge block
- Three devices: light, thermostat, lock
- Fault history with previous resolution notes

### examples/construction_site/
- Concrete pour monitoring
- Temperature and slump readings
- Hold point trigger rule
- Weather condition in knowledge block

---

## Phase 11 — Cross-SDK Integration Tests

- [ ] `tests/cross_sdk/test_compatibility.py`
  - Generate a card using Python SDK
  - Write to disk
  - Read and validate using TypeScript SDK (via subprocess)
  - Read and validate using Rust SDK (via subprocess)
  - Assert all three produce identical encoded output for the same card

---

## Phase 12 — README and Documentation

- [ ] `README.md` — project overview, installation, quickstart
  - Lead with the problem statement (not with features)
  - Cold chain example as the primary quickstart
  - Link to BuildVis as a reference production implementation
  - Architecture diagram (ASCII)
  - Link to each example

- [ ] `python/README.md` — Python-specific installation and usage
- [ ] `typescript/README.md` — TypeScript-specific
- [ ] `rust/README.md` — Rust-specific

---

## Definition of Done for v0.1

- [ ] All Phase 0–12 tasks complete
- [ ] All tests passing in all three SDKs
- [ ] Cross-SDK compatibility test passing
- [ ] CLI works end-to-end with all three example definitions
- [ ] `contextpack inspect` correctly reports token counts for a card
- [ ] A card generated from the cold_chain example can be fed directly
      to Ollama and produces a coherent, rule-grounded response
- [ ] README is readable by someone who has never heard of ContextPack
      and gives them a working card within 10 minutes
