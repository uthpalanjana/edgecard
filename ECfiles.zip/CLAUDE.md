# ContextPack — Claude Code Master Briefing

## What You Are Building

ContextPack is an open-source SDK and schema standard for generating
**model-ready context documents** (called "cards") for local LLM inference.

The core problem it solves: local LLMs (Ollama, llama.cpp, etc.) have no
standard way to receive device-specific, offline-capable, pre-assembled
context. RAG requires connectivity and retrieval latency. MCP requires a
live server. Fine-tuning requires training data. ContextPack requires none
of these — it pre-assembles everything a model needs into a single
structured document that is read once at inference time.

A card contains:
- **Identity** — what this device/system is
- **State snapshot** — current readings, derived trends, data age
- **Knowledge** — domain rules, thresholds, what readings mean
- **History** — fault history, previous events, pattern data
- **Instructions** — auto-generated model directives from user-defined rules

The instructions block is the decisive feature. It translates domain rules
written by non-ML experts into model-ready directives that reliably shape
reasoning without touching the model or writing prompts.

---

## Repository Structure

```
contextpack/
├── CLAUDE.md                  ← you are here
├── docs/
│   ├── 01_SCHEMA.md           ← card schema specification
│   ├── 02_ARCHITECTURE.md     ← system architecture
│   ├── 03_IMPLEMENTATION.md   ← build plan and task list
│   ├── 04_ADAPTERS.md         ← sensor adapter specifications
│   └── 05_ENCODINGS.md        ← output encoding specifications
├── python/                    ← Python SDK (primary)
│   ├── contextpack/
│   │   ├── __init__.py
│   │   ├── card.py            ← CardDefinition, Card
│   │   ├── writer.py          ← CardWriter (assembly + scheduling)
│   │   ├── rules.py           ← Rule, RuleEngine
│   │   ├── sources.py         ← DataSource base class
│   │   ├── adapters/
│   │   │   ├── mqtt.py
│   │   │   ├── modbus.py
│   │   │   ├── rest.py
│   │   │   ├── file.py
│   │   │   └── mock.py
│   │   ├── encoders/
│   │   │   ├── yaml_encoder.py
│   │   │   ├── json_encoder.py
│   │   │   ├── toon_encoder.py
│   │   │   └── text_encoder.py
│   │   ├── crypto.py          ← signing + encryption
│   │   └── validator.py       ← schema validation
│   ├── cli/
│   │   └── main.py            ← CLI entry point
│   ├── tests/
│   └── pyproject.toml
├── typescript/                ← TypeScript SDK
│   ├── src/
│   │   ├── index.ts
│   │   ├── card.ts
│   │   ├── writer.ts
│   │   ├── rules.ts
│   │   ├── adapters/
│   │   └── encoders/
│   ├── tests/
│   └── package.json
├── rust/                      ← Rust SDK
│   ├── src/
│   │   ├── lib.rs
│   │   ├── card.rs
│   │   ├── writer.rs
│   │   ├── rules.rs
│   │   ├── adapters/
│   │   └── encoders/
│   └── Cargo.toml
├── schema/
│   └── contextpack-v1.schema.json   ← canonical JSON Schema
├── examples/
│   ├── cold_chain/
│   ├── smart_home/
│   └── construction_site/
└── README.md
```

---

## Build Order

Read the docs in order before writing any code:

1. `docs/01_SCHEMA.md` — understand the card structure first
2. `docs/02_ARCHITECTURE.md` — understand how components fit together
3. `docs/03_IMPLEMENTATION.md` — follow the task order exactly
4. `docs/04_ADAPTERS.md` — implement adapters after core is stable
5. `docs/05_ENCODINGS.md` — implement encoders after adapters

**Do not skip ahead. The schema drives everything else.**

---

## Critical Constraints

- The schema is the source of truth. All three SDKs must produce
  identical card output for the same input.
- The instructions block must be generated automatically from Rule
  objects. Users never write prompt text manually.
- Cards stored on disk use YAML. Cards injected into models use the
  encoding specified at CardWriter initialisation (default: TOON for
  structured sections, plain text for instructions block).
- Token budget enforcement is mandatory. The CardWriter must refuse to
  write a card that exceeds the configured token ceiling. It summarises,
  not truncates.
- Encryption and signing are v0.1 requirements, not optional.
- Every adapter must implement a `test_connection()` method.
- The CLI must be usable without writing Python — it is the primary
  testing interface for non-developer users.

---

## Guiding Principles

**Model-readiness over completeness.** A card that fits in 400 tokens
and is perfectly structured beats a card with everything in 4000 tokens.

**Domain language in, model directives out.** Users write rules in their
domain ("temperature above 8°C means discard"). The library produces
model instructions. This translation is the core value.

**No connectivity assumptions.** Every feature must work fully offline.
No feature may require a network call at card read time.

**Identical schema across all three SDKs.** A card written by the Python
SDK must be readable by the TypeScript and Rust SDKs without conversion.

---

## Key Terminology

| Term | Meaning |
|---|---|
| Card | A single model-ready context document for one device/system |
| CardDefinition | The user-authored template: identity, knowledge, rules, sources |
| CardWriter | The runtime process that polls sources and assembles cards |
| Rule | A domain condition + directive pair authored by the user |
| Instructions block | Auto-generated model directives derived from Rules |
| State snapshot | Live readings + derived state written on each write cycle |
| History block | Recent events, faults, and patterns for this entity |
| Adapter | A connector between a data source protocol and the card schema |
| Encoder | Serialises a card into a specific format for model injection |
| Token budget | Maximum tokens allowed in an injected card |

---

## Reference Examples

Three reference implementations are required in `/examples/`:

**cold_chain/** — Pharmaceutical refrigeration unit. Demonstrates:
product-specific stability rules in the instructions block, breach
detection, recoverable vs non-recoverable classification.

**smart_home/** — Apartment device support. Demonstrates: device fault
history, network topology rules, Thread mesh reasoning directives.

**construction_site/** — Hold point inspection. Demonstrates: sensor
readings (concrete temperature, slump), ITP rules, hold point triggers.

Each example must include a working `demo.py` / `demo.ts` that generates
a card and prints the TOON-encoded output ready for Ollama injection.
