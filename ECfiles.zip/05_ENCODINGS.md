# ContextPack Encoding Specifications

## Overview

ContextPack separates storage format from injection format.

**Storage format (always YAML):** How cards are written to disk.
Human-readable, easy to audit, easy to diff in version control.

**Injection format (configurable):** How cards are serialised for
injection into a model's context window. Optimised for token efficiency
and model comprehension, not human readability.

The `CardReader.encode_for_model()` method handles the conversion from
storage format to injection format. The model never sees raw YAML unless
the consumer explicitly requests YAML encoding.

---

## Available Encodings

| Encoding | Use case | Token cost |
|---|---|---|
| TOON | Default model injection | Lowest for array data |
| JSON | Programmatic consumption, debugging | Medium |
| YAML | Human review, disk storage | Medium |
| Plain text | Narrative summary, very simple models | Variable |

---

## TOON Encoding

TOON (Token-Oriented Object Notation) is the default encoding for model
injection. It encodes uniform arrays (readings, history events, facts) in
a CSV-like header+rows format that eliminates repeated keys, reducing
token usage by 30-60% compared to JSON for array data.

Reference: https://github.com/toon-format/toon

### Card Sections and Their TOON Encoding

**Identity block — YAML-like key-value (non-uniform, TOON not beneficial)**
```
## CARD: coldchain-unit-03-PHARM-WH-A
card_type: system
subject: Refrigeration Unit 3 - Vaccine Storage
location: Warehouse A, Bay 4, Colombo Distribution Centre
generated_at: 2026-03-21T02:14:33Z
valid_until: 2026-03-21T02:44:33Z
data_age_seconds: 47
```

**State readings block — TOON array**
```
readings[3]{field,value,unit,quality,trend,rate_of_change_per_hour}:
temperature_c,8.7,celsius,measured,rising,1.2
compressor_status,OFF,,measured,,,
door_status,CLOSED,,measured,,,
```

**Derived state block — YAML-like key-value**
```
derived:
breach_active: true
breach_started: 2026-03-21T02:08:00Z
breach_duration_minutes: 6
fault_count_last_30_days: 2
```

**Knowledge thresholds — TOON array**
```
thresholds[2]{field,operator,value,severity,label}:
temperature_c,gt,8.0,critical,Temperature critical breach
temperature_c,gt,7.5,warning,Temperature warning
```

**Knowledge facts — TOON array**
```
facts[2]{key,value}:
mrna_stability,COVID-19 mRNA vaccines require 2-8C. Zero tolerance above 8C. Discard immediately on breach.
hepb_stability,Hepatitis B (Engerix-B) tolerates up to 12C for max 72 hours cumulative.
```

**History events — TOON array**
```
history[2]{event_id,event_type,timestamp,severity,resolved,resolution}:
evt-002,fault,2026-02-14T11:20:00Z,critical,true,Compressor restart resolved fault
evt-001,fault,2026-01-30T03:10:00Z,warning,true,Door seal replaced
```

**Instructions block — PLAIN TEXT (never TOON)**
```
## INSTRUCTIONS
Role: You are a cold chain incident assistant for Warehouse A. Reason
only from the data in this card.

Freshness: If data_age_seconds exceeds 300, preface your response with:
WARNING - readings may be stale.

Rules:
1. [CRITICAL] If state readings temperature_c value exceeds 8.0 AND
   compressor_status value is OFF, classify as equipment failure, not
   a door event.
2. [CRITICAL] If breach is classified NON-RECOVERABLE, recommend
   quarantine as the FIRST action. Do not suggest monitoring.
3. [WARNING] If fault_count_last_30_days exceeds 1 for the same fault
   pattern, recommend hardware inspection rather than self-recovery.

Do not invent readings, thresholds, or contact details not present
in this card.

Output format:
- Breach status: [NON-RECOVERABLE / RECOVERABLE / NO BREACH]
- Affected products and status
- Probable cause
- Recommended action
- Contact: [name and number]

Escalation contacts:
- Warehouse Supervisor: +94771234567
- Cold Chain Officer: +94779876543
```

### Complete TOON Card (model injection string)

```
## CARD: coldchain-unit-03-PHARM-WH-A
card_type: system
subject: Refrigeration Unit 3 - Vaccine Storage
location: Warehouse A, Bay 4, Colombo Distribution Centre
generated_at: 2026-03-21T02:14:33Z
valid_until: 2026-03-21T02:44:33Z
data_age_seconds: 47

readings[3]{field,value,unit,quality,trend,rate_of_change_per_hour}:
temperature_c,8.7,celsius,measured,rising,1.2
compressor_status,OFF,,measured,,,
door_status,CLOSED,,measured,,,

derived:
breach_active: true
breach_started: 2026-03-21T02:08:00Z
breach_duration_minutes: 6
fault_count_last_30_days: 2

thresholds[2]{field,operator,value,severity,label}:
temperature_c,gt,8.0,critical,Temperature critical breach
temperature_c,gt,7.5,warning,Temperature warning

facts[2]{key,value}:
mrna_stability,COVID-19 mRNA vaccines require 2-8C. Zero tolerance above 8C. Discard immediately on breach.
hepb_stability,Hepatitis B (Engerix-B) tolerates up to 12C for max 72 hours cumulative.

history[2]{event_id,event_type,timestamp,severity,resolved,resolution}:
evt-002,fault,2026-02-14T11:20:00Z,critical,true,Compressor restart resolved fault
evt-001,fault,2026-01-30T03:10:00Z,warning,true,Door seal replaced

## INSTRUCTIONS
Role: You are a cold chain incident assistant for Warehouse A. Reason
only from the data in this card.

Freshness: If data_age_seconds exceeds 300, preface your response with:
WARNING - readings may be stale.

Rules:
1. [CRITICAL] If state readings temperature_c value exceeds 8.0 AND
   compressor_status value is OFF, classify as equipment failure, not
   a door event.
2. [CRITICAL] If breach is classified NON-RECOVERABLE, recommend
   quarantine as the FIRST action. Do not suggest monitoring.
3. [WARNING] If fault_count_last_30_days exceeds 1 for the same fault
   pattern, recommend hardware inspection rather than self-recovery.

Do not invent readings, thresholds, or contact details not present
in this card.

Output format:
- Breach status: [NON-RECOVERABLE / RECOVERABLE / NO BREACH]
- Affected products and status
- Probable cause
- Recommended action
- Contact: [name and number]

Escalation contacts:
- Warehouse Supervisor: +94771234567
- Cold Chain Officer: +94779876543
```

### TOON Encoder Implementation Notes

1. The encoder must handle missing optional fields in arrays gracefully.
   Empty fields in a TOON row are represented by consecutive commas.
   ```
   compressor_status,OFF,,measured,,,
   ```

2. Values containing commas must be quoted:
   ```
   facts[1]{key,value}:
   note,"Temperature range: 2,8 degrees"
   ```

3. The array header `readings[N]` must declare the exact row count N.
   The encoder must count rows before writing the header.

4. The `## INSTRUCTIONS` section separator is mandatory and must always
   appear after all structured blocks.

5. The `## CARD: {card_id}` header is mandatory and must always be the
   first line of the encoded output.

6. For multi-card encoding (primary + dependencies), each card is
   separated by `\n---\n`:
   ```
   ## CARD: hub-gateway-01
   [hub card encoded]
   ---
   ## CARD: device-sensor-01
   [device card encoded]
   ```

---

## JSON Encoding

Standard JSON serialisation of the card object. Used for:
- Programmatic consumption (parsing the card in application code)
- Debugging and inspection
- API responses

The JSON encoder produces the complete card as a JSON object matching
the schema. It does not apply any TOON optimisations.

```json
{
  "contextpack_version": "0.1.0",
  "card_id": "coldchain-unit-03-PHARM-WH-A",
  "state": {
    "data_age_seconds": 47,
    "readings": {
      "temperature_c": {
        "value": 8.7,
        "unit": "celsius",
        "quality": "measured",
        "timestamp": "2026-03-21T02:14:00Z",
        "trend": "rising",
        "rate_of_change": 1.2
      }
    }
  }
}
```

The JSON encoder includes the instructions block as a structured object,
not plain text. This is appropriate for programmatic use but not for
direct model injection (models handle plain text instructions better).

---

## YAML Encoding

The storage format. Identical to the on-disk representation. Used for:
- Writing to disk (the only format used for storage)
- Human review and auditing
- Version control diffing
- Configuration management

The YAML encoder is the authoritative serialiser. The JSON and TOON
encoders derive from the YAML representation.

---

## Plain Text Encoding

A human-readable narrative format. Used for:
- Very simple models that handle structured formats poorly
- Debugging and understanding what the model sees
- Operator-facing display (not model injection)

```
CARD: Refrigeration Unit 3 - Vaccine Storage
Location: Warehouse A, Bay 4, Colombo Distribution Centre
Generated: 2026-03-21 02:14:33 UTC (47 seconds ago)

CURRENT STATE:
- Temperature: 8.7°C (RISING at 1.2°C/hour) [CRITICAL - exceeds 8.0°C threshold]
- Compressor: OFF
- Door: CLOSED
- Active breach: YES (started 02:08, duration 6 minutes)
- Fault count (30 days): 2

PRODUCT KNOWLEDGE:
- COVID-19 mRNA vaccines: require 2-8°C, zero tolerance above 8°C
- Hepatitis B (Engerix-B): tolerates up to 12°C for max 72 hours cumulative

RECENT HISTORY:
- 2026-02-14: Fault - temperature breach 9.1°C (RESOLVED: compressor restart)
- 2026-01-30: Warning - temperature 7.8°C door seal issue (RESOLVED: seal replaced)

INSTRUCTIONS:
You are a cold chain incident assistant. Reason only from the data above.
[...instructions...]
```

---

## Encoding Selection Guide

```python
from contextpack import CardReader, Encoding

reader = CardReader()
card = reader.load("./cards/my-device.card.yaml")

# For model injection (recommended)
model_input = reader.encode_for_model([card], encoding=Encoding.TOON)

# For debugging
debug_view = reader.encode_for_model([card], encoding=Encoding.PLAIN_TEXT)

# For programmatic use
json_str = reader.encode_for_model([card], encoding=Encoding.JSON)

# Force YAML (e.g. to inspect storage format)
yaml_str = reader.encode_for_model([card], encoding=Encoding.YAML)
```

**Default behaviour:** If `encoding` is not specified, TOON is used.

---

## Token Count Comparison

Expected token counts for the cold chain example card across encodings.
These are target ranges — the implementation must achieve TOON being
lowest for cards with array data.

| Block | JSON tokens | TOON tokens | Reduction |
|---|---|---|---|
| Identity (key-value) | ~80 | ~70 | ~12% |
| State readings (3 fields) | ~120 | ~55 | ~54% |
| Knowledge thresholds (2) | ~90 | ~45 | ~50% |
| Knowledge facts (2) | ~80 | ~60 | ~25% |
| History events (2) | ~130 | ~65 | ~50% |
| Instructions (plain text) | ~200 | ~200 | 0% |
| **Total** | **~700** | **~495** | **~29%** |

Note: Instructions block is always plain text in both encodings, so
savings come entirely from the structured data blocks. Cards with more
history events or more readings will see proportionally larger savings.

The `contextpack inspect` CLI command must display per-block token counts
for both JSON and TOON to help users understand the budget impact of
their card definitions.
