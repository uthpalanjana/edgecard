# ContextPack Adapter Specifications

## Overview

Adapters are the bridge between physical data sources and the card schema.
They have one responsibility: translate a data source's native format into
a dict of `{field_name: Reading}` objects. They do not interpret values,
apply thresholds, or make decisions. That is the RuleEngine's job.

All adapters implement the `DataSource` abstract base class. All adapters
must implement `test_connection()`. All adapters must handle failure
gracefully — a failed poll must never crash the CardWriter.

---

## Reading Object

Every adapter returns values as `Reading` objects:

```python
@dataclass
class Reading:
    value: Union[float, int, str, bool]
    unit: Optional[str]
    quality: Quality          # measured | estimated | stale | simulated
    timestamp: datetime
    raw_value: Optional[Any]  # original value before any transformation
```

---

## Mock Adapter

**Purpose:** Testing, development, and demonstration without hardware.

**Python**
```python
from contextpack.adapters.mock import MockAdapter

# Static values
adapter = MockAdapter(
    name="mock_sensor",
    fields={
        "temperature_c": MockField(value=22.5, unit="celsius"),
        "humidity_pct": MockField(value=65.0, unit="percent"),
        "status": MockField(value="ON")
    }
)

# Dynamic values (callable)
import math, time
adapter = MockAdapter(
    name="mock_sensor",
    fields={
        "temperature_c": MockField(
            value_fn=lambda: 22.5 + math.sin(time.time() / 60) * 2,
            unit="celsius"
        )
    }
)

# Seeded random variation (for reproducible tests)
adapter = MockAdapter(
    name="mock_sensor",
    fields={"temperature_c": MockField(value=22.5, unit="celsius",
                                        noise=0.5, seed=42)},
)
```

**Behaviour:**
- `poll()` always succeeds
- Returns `quality: simulated`
- Dynamic fields call the callable on every poll
- Noise adds gaussian variation with given sigma if seed is set

**test_connection():** Always returns success.

---

## File / CSV Adapter

**Purpose:** Reading sensor data from files. Useful for:
- Log replay during testing
- Systems that write sensor data to shared files
- Simple single-board computer setups that dump readings to disk

**CSV Format (expected):**
```
timestamp,field_name,value,unit
2026-03-21T08:00:00Z,temperature_c,22.5,celsius
2026-03-21T08:00:00Z,humidity_pct,65.0,percent
```

**JSON Format (expected):**
```json
{
  "temperature_c": {"value": 22.5, "unit": "celsius", "timestamp": "2026-03-21T08:00:00Z"},
  "humidity_pct": {"value": 65.0, "unit": "percent", "timestamp": "2026-03-21T08:00:00Z"}
}
```

**Python**
```python
from contextpack.adapters.file import FileAdapter

# CSV
adapter = FileAdapter(
    name="file_sensor",
    path="/var/data/sensors.csv",
    format="csv",
    watch=True          # re-read file on every poll (default: True)
)

# JSON
adapter = FileAdapter(
    name="file_sensor",
    path="/var/data/sensors.json",
    format="json"
)
```

**Behaviour:**
- `poll()` reads the file fresh on every call if `watch=True`
- On file not found: returns all fields as `quality: stale`
- On parse error: returns all fields as `quality: stale`, logs error
- Timestamps in the file are used as `Reading.timestamp`
- If a file has no timestamps: uses poll time

**test_connection():** Checks file exists and is readable. Returns
failure if file does not exist.

---

## REST / HTTP Adapter

**Purpose:** Polling HTTP endpoints that return sensor data. Covers:
- Smart home hubs (Home Assistant, SmartThings, custom)
- Industrial gateways with REST APIs
- Any device exposing an HTTP endpoint

**Python**
```python
from contextpack.adapters.rest import RESTAdapter, EndpointMapping

adapter = RESTAdapter(
    name="home_assistant",
    base_url="http://homeassistant.local:8123",
    headers={"Authorization": "Bearer eyJ..."},
    timeout_seconds=5,
    endpoints=[
        EndpointMapping(
            endpoint="/api/states/sensor.living_room_temperature",
            field="temperature_c",
            unit="celsius",
            json_path="state",              # dot-notation into response JSON
            transform=float                 # optional transform function
        ),
        EndpointMapping(
            endpoint="/api/states/switch.living_room_light",
            field="light_status",
            json_path="state"
        )
    ]
)
```

**json_path examples:**
- `"state"` → `response["state"]`
- `"attributes.temperature"` → `response["attributes"]["temperature"]`
- `"data.sensors[0].value"` → `response["data"]["sensors"][0]["value"]`

**Behaviour:**
- `poll()` fires all endpoint requests in parallel (async) or with
  threading. Collects results. On partial failure, returns what succeeded
  with failed fields as `quality: stale`.
- HTTP 4xx/5xx: field returned as stale, error logged
- Timeout: field returned as stale, timeout logged
- Retry: 1 retry with 1s backoff (not configurable in v0.1)

**Authentication options:**
```python
# Bearer token
auth=BearerAuth(token="eyJ...")

# Basic auth
auth=BasicAuth(username="admin", password="secret")

# API key header
auth=APIKeyAuth(header="X-API-Key", key="abc123")

# No auth (default)
```

**test_connection():** Fires HEAD request to `base_url`. Returns success
if HTTP 200-499 (even 401/403 means the server is reachable).

---

## MQTT Adapter

**Purpose:** Subscribing to MQTT broker topics. The most common IoT
protocol. Covers:
- Smart home sensors (Zigbee2MQTT, Tasmota, ESPHome)
- Industrial sensors via MQTT bridge
- Any MQTT-compatible device

**Python**
```python
from contextpack.adapters.mqtt import MQTTAdapter, MQTTTopicMapping

adapter = MQTTAdapter(
    name="mqtt_sensors",
    broker_host="192.168.1.100",
    broker_port=1883,
    client_id="contextpack_unit3",    # optional, auto-generated if not set
    username="mqtt_user",              # optional
    password="mqtt_pass",              # optional
    keepalive_seconds=60,
    reconnect_delay_seconds=5,
    topics=[
        MQTTTopicMapping(
            topic="zigbee2mqtt/temp_sensor_01",
            field="temperature_c",
            unit="celsius",
            json_path="temperature"     # optional, for JSON payloads
        ),
        MQTTTopicMapping(
            topic="home/unit3/compressor/status",
            field="compressor_status",
            json_path=None              # plain string payload
        ),
        MQTTTopicMapping(
            topic="zigbee2mqtt/temp_sensor_01",
            field="humidity_pct",
            unit="percent",
            json_path="humidity"        # second field from same topic
        )
    ]
)
```

**Payload handling:**
- Plain string payload: used as value directly
- JSON payload: `json_path` extracts the value
- Multiple fields from one topic: define multiple MQTTTopicMappings
  with the same topic and different `json_path` values

**Behaviour:**
- Adapter maintains a persistent MQTT connection from `start()` until `stop()`
- Incoming messages update an internal in-memory latest-value store
- `poll()` reads from the latest-value store — it does NOT fire a
  new request. This is the key difference from REST.
- If no message has been received for a topic since the last poll:
  returns `quality: stale`
- If no message ever received for a topic: returns `quality: stale`
  with `value: None`
- Auto-reconnects on disconnect with exponential backoff up to
  `reconnect_delay_seconds * 10`
- QoS 1 for all subscriptions

**TLS support:**
```python
adapter = MQTTAdapter(
    ...
    tls=MQTTTLSConfig(
        ca_cert_path="/etc/certs/ca.crt",
        client_cert_path="/etc/certs/client.crt",    # optional
        client_key_path="/etc/certs/client.key"      # optional
    )
)
```

**test_connection():**
1. Connect to broker
2. Subscribe to first configured topic
3. Wait up to 5 seconds for any message
4. Disconnect
5. Return success if connection established (message not required)

---

## Modbus Adapter

**Purpose:** Reading from Modbus TCP/RTU devices. The most common
industrial protocol. Covers:
- PLCs (Siemens, Allen-Bradley, Mitsubishi)
- VFDs (Variable Frequency Drives)
- Power meters, flow meters, industrial sensors
- Building automation controllers (DDC units)

**Register Types:**

| Type | Read | Write | Data |
|---|---|---|---|
| Holding Register | ✓ | ✓ | 16-bit words |
| Input Register | ✓ | ✗ | 16-bit words |
| Coil | ✓ | ✓ | Boolean |
| Discrete Input | ✓ | ✗ | Boolean |

**Python**
```python
from contextpack.adapters.modbus import ModbusAdapter, RegisterMapping

adapter = ModbusAdapter(
    name="plc_unit3",
    host="192.168.1.50",
    port=502,
    unit_id=1,              # Modbus slave/unit ID
    timeout_seconds=3,
    registers=[
        RegisterMapping(
            address=100,
            field="temperature_c",
            register_type="holding",
            data_type="float32",    # reads 2 consecutive registers
            scale_factor=0.1,       # raw value × scale_factor = engineering value
            unit="celsius"
        ),
        RegisterMapping(
            address=102,
            field="pressure_bar",
            register_type="holding",
            data_type="uint16",
            scale_factor=0.01,
            unit="bar"
        ),
        RegisterMapping(
            address=200,
            field="compressor_running",
            register_type="coil",
            data_type="boolean"
        ),
        RegisterMapping(
            address=300,
            field="fault_code",
            register_type="input",
            data_type="uint16",
            scale_factor=1.0
        )
    ]
)
```

**Data Types and Register Count:**

| data_type | Registers | Notes |
|---|---|---|
| uint16 | 1 | Unsigned 16-bit integer |
| int16 | 1 | Signed 16-bit integer |
| uint32 | 2 | Big-endian by default |
| int32 | 2 | Big-endian by default |
| float32 | 2 | IEEE 754, big-endian by default |
| boolean | 1 (coil) | For coils and discrete inputs only |

**Byte order:** Default big-endian (Modbus standard). Override:
```python
RegisterMapping(..., byte_order="little", word_order="little")
```

**Behaviour:**
- `poll()` groups all registers by type and fires minimal read operations
  (e.g. 5 consecutive holding registers read in one request, not 5 requests)
- On connection failure: all registers returned as `quality: stale`
- On partial read failure: successful registers returned, failed as stale
- Connection is established fresh on each poll cycle (stateless)
  This is safer for industrial environments and avoids stale connection state

**RTU (Serial) support (v0.1):**
```python
adapter = ModbusAdapter(
    name="rtu_sensor",
    mode="rtu",
    port="/dev/ttyUSB0",
    baudrate=9600,
    parity="N",
    stopbits=1,
    bytesize=8,
    unit_id=1,
    registers=[...]
)
```

**test_connection():**
1. Connect to host:port (TCP) or open serial port (RTU)
2. Read holding register 0 from unit_id
3. Disconnect
4. Return success if no exception raised
5. Connection failure, timeout, and no-response all return failure
   with the exception message

---

## Adding New Adapters

Third-party adapters can be registered without modifying the ContextPack
source:

```python
from contextpack import DataSource, Reading

class MyCustomAdapter(DataSource):
    def __init__(self, name: str, ...):
        super().__init__(name=name)
        ...

    def poll(self) -> dict[str, Reading]:
        # your implementation
        ...

    def test_connection(self) -> ConnectionResult:
        # your implementation
        ...

# Register and use
definition.add_data_source(MyCustomAdapter(name="my_source", ...))
```

The adapter contract is minimal by design. Any object implementing
`poll()` and `test_connection()` with the correct signatures is a valid
ContextPack adapter.

---

## Adapter Error Handling Reference

All adapters must follow this error handling contract:

| Situation | poll() behaviour | test_connection() behaviour |
|---|---|---|
| Connection refused | Return all fields as stale, log error | Return ConnectionResult(success=False, message=...) |
| Timeout | Return all fields as stale, log warning | Return failure |
| Auth failure | Return all fields as stale, log error | Return failure with auth message |
| Partial data | Return successful fields, failed as stale | N/A |
| Parse error | Return field as stale, log error with raw value | N/A |
| File not found | Return all fields as stale | Return failure |

**Never raise exceptions from poll().** The CardWriter must not crash
due to an adapter failure. Log and return stale.

**Always raise from test_connection() if there is a programming error**
(wrong adapter type, invalid configuration). Return failure for
runtime connectivity issues.
